# rbe474x_p0
Deep Learning for Perception - P0

`git clone git@github.com:pearwpi/rbe474x_p0.git <YourDirectoryID>_p0`

Zip the repo up and submit. For this project, its okay to submit the zip of the whole folder as it is small enough. Folder structure and naming guidelines are also given in the website.

Please indicate if you are using late days in the report pdf and also in the comments section in canvas (while uploading the zip). Otherwise, I will assume that you are not using any late days, even if you have some left.
