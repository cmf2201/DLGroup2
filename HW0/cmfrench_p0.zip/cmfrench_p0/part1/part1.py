# Imports 
import numpy as np
import torch
from torchvision import transforms
import scipy
import time
from PIL import Image
import matplotlib.pyplot as plt
import cv2
import nbimporter
import unittest

from utils import *

image_pil = Image.open('main.jpg').convert('L')
image = np.array(image_pil)

KERNEL = np.array(
    [
        [1, 0, -1], 
        [2, 0, -2],
        [1, 0, -1]
    ]
)
## 3. Convolution Methods
def filter_scipy_convolve2d(img, kernel):
    start =time.time()
    filtered_image = np.zeros_like(img).astype(np.float64)
    
    # Write Your Code Here!
    # Convolve the image with the kernel using scipy.signal.convolve2d
    filtered_image = scipy.signal.convolve2d(img, kernel, mode='same')
    
    print("Elapsed time (s)=", time.time() - start)
    return filtered_image
img = filter_scipy_convolve2d(image, KERNEL)
writeDoubleImage(img, "scipy.jpg")

def filter_numpy_for_loop(img, kernel):
    start = time.time()
    
    filtered_image = np.zeros_like(img).astype(np.float64)

    # Convert img to float to get more accurate results
    img = img.astype(np.float64)
    
    # Convolve the image with the kernel using nested for loops
    for i in range(1, img.shape[0]-1):
        for j in range(1, img.shape[1]-1):
            # find the element-wise product of the flipped kernel and the image patch
            filtered_image[i, j] = np.sum(img[i-1:i+2, j-1:j+2] * np.flip(kernel))

    print("Elapsed time (s)=", time.time() - start)
    return filtered_image
img = filter_numpy_for_loop(image, KERNEL)

writeDoubleImage(img, "numpy_for_loop.jpg")

def filter_torch(img, kernel):
    start = time.time()
    print(img.shape)

    # Convert our Kernel to a tensor
    kernel = torch.tensor(np.flip(kernel).copy(),dtype=torch.float64)

    # Create our conv2d layer
    conv = torch.nn.Conv2d(1,1,kernel_size=kernel.shape,stride=1, padding=1,bias=False)

    # Initalize weights with our kernel
    with torch.no_grad():
        conv.weight = torch.nn.Parameter(kernel.unsqueeze(0).unsqueeze(0)) 
    
    # Convert our image to a tensor
    img = torch.tensor(img,dtype=torch.float64).unsqueeze(0)

    # Perform the convolution
    filtered_image = conv(img)
    print(filtered_image.shape)

    print("Elapsed time (s)=", time.time() - start)
    return filtered_image.squeeze(0).squeeze(0).detach().numpy()
img = filter_torch(image, KERNEL)
writeDoubleImage(img, "torch_conv.jpg")